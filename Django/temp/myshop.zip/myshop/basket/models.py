from django.db import models

class Basket(models.Model):
    product_id = models.IntegerField()
# Create your models here.
